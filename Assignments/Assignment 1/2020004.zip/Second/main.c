#include<stdio.h>
#include<stdlib.h>
#include<stdint.h>
#include<unistd.h>
#include<string.h>
extern void A();

int main(){
    A();
    return 0;
}